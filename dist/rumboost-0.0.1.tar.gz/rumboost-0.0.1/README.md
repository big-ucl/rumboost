# RUMBoost
Gradient Boosted Random Utility Models

The code will be available shortly. We are currently working on implementing some extensions for the model, and we will release a full version of the code once this is finished.
